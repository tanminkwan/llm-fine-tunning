10:45분까지 진행하세요

BERT Large + LoRA + QA  실습

1. Classification 실습에서 사용하셨던 "BERT_LORA_LARGE_CLS.ipynb" 파일을 참고하세요
2. QA 실습 첫번째 노트북인 "5_BERT_LORA_SMALL_QA.ipynb"를 복사하여서 아래의 내용을 추가 및 수정하세요
	a) 모델 이름 : "bert-large-uncased" 이용
	b) Quantization  사용해서 모델 로딩
	c) Gradient CheckPointing
	d) LoRA 화 시키기
	d) fp16 = True
	e) Gradient Accumulation


