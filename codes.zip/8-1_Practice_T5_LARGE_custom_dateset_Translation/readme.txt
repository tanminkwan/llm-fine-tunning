3:20분까지 해보세요

Date Translation 예제를 PEFT화 해보세요
참고파일: T5_SMALL_DATE_Translation.ipynb

1. model 을 큰 모델로 바꿉니다.
	MODEL_ID = "t5-large"

2. PEFT 옵션을 켜서 구동시키세요
	a) LoRA 적용
	b) int8 적용
	c) Optional
		- fp16=False
		- gradient check point 
		- accumulation 
